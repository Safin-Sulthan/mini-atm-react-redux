import React from 'react';
import { useSelector, useDispatch } from 'react-redux';
import { useState } from 'react';
import './Withdraw.css';
export default function Withdraw({ setScreen }) {
  const balance = useSelector((state) => state.account.balance);
  const [amount, setAmount] = useState('');
  const dispatch = useDispatch();

  function handleWithdraw() {
    const withdrawAmount = Number(amount);
    if (withdrawAmount <= 0) {
      alert('*** Enter Valid Amount ***');
      return;
    }
    if (withdrawAmount > balance) {
      alert('!!! Insufficient Balance !!!');
      return;
    }
    dispatch({ type: 'WITHDRAW', payload: withdrawAmount });
    alert('***** Amount WithDrawn Sucessful *****');
    setAmount('');
    setScreen('menu');
  }
  return (
    <div className="withdraw-container">
      <div className="withdraw-card">
        <div className="withdraw-header">
          <h3>Withdraw Money</h3>
          <div className="withdraw-body">
            <p>Available Balance: ₹{balance}</p>
            <input
              type="number"
              placeholder="Enter Amount to With Draw"
              value={amount}
              onChange={(e) => setAmount(e.target.value)}
            />
            <div className="withdraw-footer">
              <button className="withdraw-btn" onClick={handleWithdraw}>
                With Draw
              </button>
              <button className="back-button" onClick={() => setScreen('menu')}>
                Back
              </button>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
